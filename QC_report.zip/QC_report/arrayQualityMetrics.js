// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false, false, false, false, true, true, false, false, false, false, false, false, false, false, false ];
var arrayMetadata    = [ [ "1", "GSM944831_2564_6914_32297_Ctl-1_Mouse430+2.CEL", "1", "2010-11-10T16:14:28Z" ], [ "2", "GSM944832_2564_6914_32298_2h-1_Mouse430+2.CEL", "2", "2010-11-10T16:23:41Z" ], [ "3", "GSM944833_2564_6914_32299_Ctl-Lin-1_Mouse430+2.CEL", "3", "2010-11-10T16:32:50Z" ], [ "4", "GSM944834_2564_6914_32300_Ctl-Van-1_Mouse430+2.CEL", "4", "2010-11-10T16:42:09Z" ], [ "5", "GSM944835_2564_6914_32301_24h-1_Mouse430+2.CEL", "5", "2010-11-10T16:51:22Z" ], [ "6", "GSM944836_2564_6914_32302_24h-lin-1_Mouse430+2.CEL", "6", "2010-11-10T17:00:43Z" ], [ "7", "GSM944837_2564_6914_32303_24h-Van-1_Mouse430+2.CEL", "7", "2010-11-10T17:10:05Z" ], [ "8", "GSM944838_2564_6914_32304_Ctl-2_Mouse430+2.CEL", "8", "2010-11-10T17:19:25Z" ], [ "9", "GSM944839_2564_6914_32305_2h-2_Mouse430+2.CEL", "9", "2010-11-10T17:40:59Z" ], [ "10", "GSM944840_2564_6914_32306_Ctl-Lin-2_Mouse430+2.CEL", "10", "2010-11-10T17:50:17Z" ], [ "11", "GSM944841_2564_6914_32307_Ctl-Van-2_Mouse430+2.CEL", "11", "2010-11-10T17:59:38Z" ], [ "12", "GSM944842_2564_6914_32308_24h-2_Mouse430+2.CEL", "12", "2010-11-10T18:08:35Z" ], [ "13", "GSM944843_2564_6914_32309_24h-lin-2_Mouse430+2.CEL", "13", "2010-11-10T18:17:56Z" ], [ "14", "GSM944844_2564_6914_32310_24h-Van-2_Mouse430+2.CEL", "14", "2010-11-10T18:27:14Z" ], [ "15", "GSM944845_2564_6914_32311_Ctl-3_Mouse430+2.CEL", "15", "2010-11-10T18:36:29Z" ], [ "16", "GSM944846_2564_6914_32312_2h-3_Mouse430+2.CEL", "16", "2010-11-10T18:45:50Z" ], [ "17", "GSM944847_2564_6914_32313_Ctl-Lin-3_Mouse430+2.CEL", "17", "2010-11-10T18:55:14Z" ], [ "18", "GSM944848_2564_6914_32314_Ctl-Van-3_Mouse430+2.CEL", "18", "2010-11-10T19:04:21Z" ], [ "19", "GSM944849_2564_6914_32315_24h-3_Mouse430+2.CEL", "19", "2010-11-10T19:13:34Z" ], [ "20", "GSM944850_2564_6914_32316_24h-lin-3_Mouse430+2.CEL", "20", "2010-11-10T19:22:48Z" ], [ "21", "GSM944851_2564_6914_32317_24h-Van-3_Mouse430+2.CEL", "21", "2010-11-10T19:32:16Z" ], [ "22", "GSM944852_2564_6914_32318_Ctl-4_Mouse430+2.CEL", "22", "2010-11-10T19:41:23Z" ], [ "23", "GSM944853_2564_6914_32319_2h-4_Mouse430+2.CEL", "23", "2010-11-10T19:50:43Z" ], [ "24", "GSM944854_2564_6914_32320_Ctl-Lin-4_Mouse430+2.CEL", "24", "2010-11-10T20:00:00Z" ], [ "25", "GSM944855_2564_6914_32321_Ctl-Van-4_Mouse430+2.CEL", "25", "2010-11-10T20:15:24Z" ], [ "26", "GSM944856_2564_6914_32322_24h-4_Mouse430+2.CEL", "26", "2010-11-10T20:24:45Z" ], [ "27", "GSM944857_2564_6914_32323_24h-lin-4_Mouse430+2.CEL", "27", "2010-11-10T20:35:13Z" ], [ "28", "GSM944858_2564_6914_32324_24h-Van-4_Mouse430+2.CEL", "28", "2010-11-10T20:44:31Z" ], [ "29", "GSM944859_2564_6914_32325_Ctl-5_Mouse430+2.CEL", "29", "2010-11-10T20:53:55Z" ], [ "30", "GSM944860_2564_6914_32326_2h-5_Mouse430+2.CEL", "30", "2010-11-10T21:03:13Z" ], [ "31", "GSM944861_2564_6914_32327_Ctl-Lin-5_Mouse430+2.CEL", "31", "2010-11-10T21:12:26Z" ], [ "32", "GSM944862_2564_6914_32328_Ctl-Van-5_Mouse430+2.CEL", "32", "2010-11-10T21:21:37Z" ], [ "33", "GSM944863_2564_6914_32329_24h-5_Mouse430+2.CEL", "33", "2010-11-10T21:30:54Z" ], [ "34", "GSM944864_2564_6914_32330_24h-lin-5_Mouse430+2.CEL", "34", "2010-11-10T21:40:07Z" ], [ "35", "GSM944865_2564_6914_32331_24h-Van-5_Mouse430+2.CEL", "35", "2010-11-10T21:49:42Z" ] ];
var svgObjectNames   = [ "pca", "dens" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
